<?php 

$servername = "localhost";
 
$username = "root";
 
$password = "";
 
$dbname = "humgexpress";
$con = mysqli_connect($servername,$username,$password,$dbname);
mysqli_set_charset($con, 'UTF8');
?>