<?php 
    $sql ="
			SELECT * FROM tin
			ORDER BY SoLanXem DESC
			LIMIT 0,10
		";
	$result = mysqli_query($con,$sql);
     while ($row_tinxemnhieunhat = mysqli_fetch_array($result)) {
  ?>
  <div class="top_list">
	<div class="top_list_img">
		<a href="index.php?p=chitiettin&idTin=<?php echo $row_tinxemnhieunhat['idTin'] ?>">
			<img src="upload/tintuc/<?php echo $row_tinxemnhieunhat['urlHinh'] ?>">
		</a>
	</div>
	<div class="list_heading">
		<a href="index.php?p=chitiettin&idTin=<?php echo $row_tinxemnhieunhat['idTin'] ?>"><?php echo $row_tinxemnhieunhat['TieuDe']; ?></a>
	</div>
</div>
<?php 
		}
?>

