<?php 
	ob_start();
	session_start();
	if(isset($_SESSION["idUser"])){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	if(isset($_POST["add"])){
			$HoTen = $_POST["HoTen"];
			$Username = $_POST["Username"];
			if($_POST['Password1']!=$_POST['Password2']){
				echo"
	    			<script>
	    				alert('Mật khẩu không khớp');
	    			</script>
	    			";
			}else{
				$Password = $_POST['Password1'];
				}
			$DiaChi = $_POST['DiaChi'];
			$Dienthoai = $_POST['Dienthoai'];
			$Email = $_POST['Email'];
			$idGroup = 0;
			$NgaySinh = $_POST['NgaySinh'];
			$GioiTinh =$_POST['GioiTinh'];
			if($HoTen==""){
			echo ("	<script>
	    				alert('Vui lòng nhập đầy đủ thông tin');
	    			</script>
	    			");
			}else if($Username==""){
			echo"
	    			<script>
	    				alert('Vui lòng nhập đầy đủ thông tin');
	    			</script>
	    			";
			}else if($Password==""){
			echo"
	    			<script>
	    				alert('Vui lòng nhập đầy đủ thông tin');
	    			</script>
	    			";
			}else if ((mysqli_num_rows(mysqli_query($con,("SELECT * FROM users WHERE Username='$Username'")))) > 0){
      		echo "
       			 <script>
	    				alert('Tên đăng nhập này đã có ngườis sử dụng!');
	    			</script>
	    			";
   			}else if ((mysqli_num_rows(mysqli_query($con,("SELECT * FROM users WHERE Email='$Email'")))) > 0){
      		echo "
       			 <script>
	    				alert('Địa chỉ email đã có người sử dụng! ');
	    			</script>
	    			";

			}else{
		
		$sql = "
		INSERT INTO users
		VALUE(null,'$HoTen','$Username','$Password','$DiaChi','$Dienthoai','$Email','idGroup','$NgaySinh','$GioiTinh')
		";
		mysqli_query($con,$sql);
		echo"
	    			<script>
	    				alert('Đăng ký thành công!');
	    			</script>
	    			";

		}
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="../admin/admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">ĐĂNG KÝ TÀI KHOẢN
			
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang chủ
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				
				<tr>
					<td class="haicot">Họ tên</td>
					<td class="haicot">
						<input type="text" name="HoTen" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Username</td>
					<td class="haicot">
						<input type="text" name="Username" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Password</td>
					<td class="haicot">
						<input type="Password" name="Password1" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Re-Password</td>
					<td class="haicot">
						<input type="Password" name="Password2" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Địa chỉ</td>
					<td class="haicot">
						<input type="text" name="DiaChi" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Điện thoại</td>
					<td class="haicot">
						<input type="number" name="Dienthoai">
					</td>
				</tr>
				<tr>
					<td class="haicot">Email</td>
					<td class="haicot">
						<input type="text" name="Email" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Ngày Sinh</td>
					<td class="haicot">
						<input type="date" name="NgaySinh" size="67">
					</td>
				</tr>
				<tr>
					<td class="haicot">Giới tính</td>
					<td class="haicot">
						<div style="float: left;margin-left: 20px">
							<input style="float: left;" type="radio" name="GioiTinh" value="1" >
							<div style="float: left;margin-top: 10px">Nam</div><br>
						</div>
						<div style="float: left; clear: both; margin-left: 20px">
							<input style="float: left;" type="radio" name="GioiTinh" value ="0" >
							<div style="float: left;margin-top: 10px">Nữ</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<a href="Login.php">Ấn vào đây để đăng nhập</a>
					</td>
					<td>
						<input type="submit" name="add" value=" Đăng Ký ">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
