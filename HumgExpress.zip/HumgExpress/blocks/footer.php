<div class="bannerft">
	<a href="./">
			<img src="images/logoft.png">
	</a>
		</div>
		<div class="txtft">
			<p>© Copyright 2018 HumgExpress. All rights reserved.</p>
			<p>Thuộc Bộ Khoa học Công nghệ. Toàn bộ bản quyền thuộc HumgExpress.</p>
		</div>