<!--Thay đổi nút home-->
<?php 
	if(!isset($_GET['idTL']) & !isset($_GET['idTin'])){
?>
 <a href="./">
	<img class="iconhome" src="images/iconhome.png">
</a>
<?php
	}else{
?>
		<a href="./">
		<img class="iconhome" src="images/iconblackhome.jpg">
		</a>
<?php
	}
?>


<?php  
	$sql = "
			SELECT * FROM theloai
		";
	$result = mysqli_query($con,$sql);
	while ($row_theloai = mysqli_fetch_array($result)) { 
	$idTL = $row_theloai['idTL'];    
		if(!isset($_GET['idTL'])){
			?>
			<a href="index.php?p=tintheotheloai&idTL=<?php echo $row_theloai['idTL'] ?>"><?php echo $row_theloai['TenTL'] ?></a>
			<?php

		}else{		
			?>
		<a <?php if($idTL == $_GET['idTL']) echo "style='color:#9f224e;'"; ?> 
		href="index.php?p=tintheotheloai&idTL=<?php echo $row_theloai['idTL'] ?>">
			<?php echo $row_theloai['TenTL'] ?>
				
			</a>
<?php 
		}
	}
?>
		 