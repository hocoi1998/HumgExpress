   <?php 	
   		if(isset($_POST["logout"])){
									unset($_SESSION["idUser"]);
									unset($_SESSION["Username"]);
									unset($_SESSION["HoTen"]);
									unset($_SESSION["idGroup"]);
									
								} ?>
<div class="taskbar_container">
		<ul class="taskbar_contact">
			<li onload="showtime()">
				<div id="dongho"></div>
			</li>
			<li class="icon-like">
				<a href="https://www.facebook.com/hocoi1998" target="_blank">
					<img src="images/iconlike.png">
				</a>
				<a href="https://twitter.com/hocoi1998" target="_blank"> 
					<img src="images/iconfollow.png">
				</a>
			</li>
		</ul>
	<div class="taskbar_right">
		<ul>
			<form>
				<li>
		        	<input type="text" name="key" placeholder="Tìm kiếm">
		        	
		       	</li>
		       	<li  style="margin-left: 1px">
		       		<button type="submit" style="border: none;">
		        		<img src="images/iconsearch.png">
		        	</button>
		       	</li>
		       	<input type="hidden" name="p" value="search">
	       	</form>	
	       
	       	<form action="" method="POST" style="font-size: 13px;" >
	       		<?php  
	       			if(isset($_SESSION['idUser'])){ 
	       			echo $_SESSION["HoTen"];
	       		?>	
					<button type="submit" name="logout">Đăng xuất</button>			
				<?php
	       			}else{

	       		?>
	       	<li>
				<button>
					<a href="blocks/login.php">
						Đăng Nhập
					</a>
				</button>
	       	</li>
	       	
	       	<li>
	       		<button><a href="blocks/register.php">Đăng ký</a></button>
	       	</li>
	       		<?php 
	       			}
	       		?>
	       	</form>


		</ul>
	</div>		
</div>
<script type="text/javascript">
					function showtime(){
						var thoigian = new Date();
						var thu = thoigian.getDay();
						arrThu=new Array("Chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy");
						var ngay = thoigian.getDate();
						var thang = thoigian.getMonth()+1;
						var nam = thoigian.getYear()+1900;
						var gio = thoigian.getHours();
							if(gio<10){
								gio ="0"+gio;
							}
						var phut = thoigian.getMinutes();
							if(phut<10){
								phut = "0"+phut;
							}
						var giay = thoigian.getSeconds();

						document.getElementById("dongho").innerHTML=arrThu[thu]+", "+ngay+"/"+thang+"/"+nam+", "+gio+":"+phut+" (GMT+7) ";
						
						setTimeout(showtime,1000);
					}
					
					showtime();
				</script>