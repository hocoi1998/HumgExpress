<div class="header_container">
	<div class="logo_express">
		<a href="./">
			<img src="images/logoexpress1.png">
		</a>
	</div>	
	<div class="sads">
		<div class="txt_sads">Quảng cáo</div>
		<div class="banner_sads">
			<?php 
				$sql = "
				SELECT * FROM quangcao
				WHERE vitri=1
				ORDER BY RAND()
				LIMIT 2";
				$result = mysqli_query($con,$sql);
				
				while ($row_quangcao = mysqli_fetch_array($result)) {
			?>
			<a href="<?php echo $row_quangcao['Url'] ?>" target ="_blank">
				<div class="sads1">
					<img src="upload/quangcao/<?php echo $row_quangcao['urlHinh'] ?>">
				</div>
			</a>
			<?php  
				}
			?>
		</div>
	</div>
</div>