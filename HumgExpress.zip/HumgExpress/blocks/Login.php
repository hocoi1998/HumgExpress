<?php 
	session_start();
	require "../lib/config.php";
?>

<form action="" method="POST">

	<table align="center" width="300">
		<caption>THÔNG TIN ĐĂNG NHẬP</caption>
		<tr>
			<td>
				Username:
			</td>
			<td>
				<input type="text" name="user">
			</td>
		</tr>
		<tr>
			<td>
				Password:
			</td>
			<td>
				<input type="Password" name="password">
			</td>
		</tr>
		<tr>
			<td>
				<a href="../index.php">Trở về</a>
			</td>
			<td>
				<input type="submit" name="login" value="Đăng Nhập">
			</td>
		</tr>
	</table>

		  	<?php 
			
	    	// Kiểm tra đăng nhập
	    	if(isset($_POST["login"])){
	    		$user = $_POST["user"];
	    		$password = $_POST["password"];
	    		$sql = "
	    			SELECT * FROM users
	    			WHERE Username = '$user'
	    			AND Password = '$password'
	    		";
	    		$result = mysqli_query($con, $sql);
	    		if(mysqli_num_rows($result)==1){
	    			$row = mysqli_fetch_array($result);
	    			$_SESSION["idUser"] = $row['idUser'];
	    			$_SESSION["Username"] = $row['Username'];
	    			$_SESSION["HoTen"] = $row['HoTen'];
	    			$_SESSION["idGroup"] = $row['idGroup'];
	    			if($_SESSION["idGroup"]==1){
 					header("location:../admin");
 					}else{
	    				header( "location: ../index.php ");
	    			}
	    		}else{
	    			echo "
	    			<script>
	    				alert('Sai thông tin tài khoản hoặc mật khẩu');
	    			</script>
	    			";
	    		}
	    		
	    		
	    	}

	    	?>

	
</form>
