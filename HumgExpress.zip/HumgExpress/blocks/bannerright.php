<!--Banner quảng cáo-->
<?php 
		$sql = "
			SELECT * FROM quangcao
			WHERE vitri=2
			ORDER BY RAND()
			LIMIT 2
			";
		$result = mysqli_query($con,$sql);
				
				while ($row_quangcao = mysqli_fetch_array($result)) {
?>
<div class="bads_img">
		<a href="<?php echo $row_quangcao['Url'] ?>" target ="_blank">
			<img src="upload/quangcao/<?php echo $row_quangcao['urlHinh'] ?>">
		</a>
</div>
<?php 
	}
?>
