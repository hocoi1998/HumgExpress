<?php 
    session_start();
    require "lib/config.php";
    if(isset($_GET["p"]))
        $p = $_GET["p"];
    else
        $p = "";
?>

<!DOCTYPE html>
<html>
<head>
	
	<title>HumgExpress - Báo tiếng Việt nhiều người xem nhất</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="maindemo.css">
</head>
<body>
	<!--Taskbar-->
	<div id="taskbar" id="">
		<?php require "blocks/taskbar.php" ?>
	</div>
	<!--END Taskbar-->
	<!--header-->
	<div id="header">
		<?php require "blocks/header.php"?>
	</div>
	<!--END header-->
	<!--Menu-->
	<nav id="menu">
		<?php require "blocks/menu.php"?>
	</nav>
	<!--END Menu-->
	<!--Container-->
	<div id="container">
		<!--pages-->
		<div class="left">
			<?php 
				switch ($p){
					case "chitiettin": require "pages/chitiettin.php"; break;
					case "search": require "pages/search.php"; break;
					case "tintheotheloai": require "pages/tintheotheloai.php";break;
					default: require "pages/trangchu.php";
				}
			?>
		</div>
		<div class="right">
			
				<?php require "blocks/right.php" ?>
			
			
			<div class="bads">
				<?php require "blocks/bannerright.php" ?>
				
			</div>
		</div>
		
	</div>
	<!--END Container-->
	<div id="footer">
		<?php require "blocks/footer.php"?>
	</div>
		<a style="position: fixed; top: 90%; right: 30px;" href="#">
			<img width="50" src="images/backtotop.png">
		</a>
			
</body>
</html>