<?php 
	if(isset($_GET["idTin"])){
		$idTin = $_GET["idTin"];
		settype($idTin, "int");
	}else{
		$idTin = 1;
	}
	$sql_view ="
			UPDATE tin
			SET SoLanXem = SoLanXem + 1
			WHERE idTin = $idTin
		";
	mysqli_query($con,$sql_view);
?>
<?php
	$sql = "
			SELECT * FROM tin
			WHERE idTin = $idTin
		";
	$result = mysqli_query($con,$sql);
	$row_tin = mysqli_fetch_array($result);
?>
<div class="chitiettin_left">
	<h2 class="title">
		<?php echo $row_tin['TieuDe'] ?>
	</h2>	
	<h4 style="text-align: justify;"><?php echo $row_tin['TomTat'] ?></h4>
	<div class="story">
		<img src="upload/tintuc/<?php echo $row_tin['urlHinh'] ?>">
	</div>
	<div class="content">
		<?php echo $row_tin['Content'] ?>	
	</div>
	<div>
		<img src="images/view.png" width="25px"; style="margin-bottom: -6px"> 
		<?php 
			echo $row_tin['SoLanXem']
		?>
	</div>
	<h3 style="color: #9f224e; margin-top: 10px;"><u>Tin liên quan</u></h3><br>
	<div class="timeline" style="border: 1px solid #ddd; padding-top: 15px">
	<?php
		$sql = "
			SELECT * FROM tin
			WHERE idTin<>$idTin
			AND idTL = $row_tin[idTL]
			ORDER BY idTin DESC
			LIMIT 3
		";
		$result = mysqli_query($con,$sql);
		
		while($tinlienquan = mysqli_fetch_array($result)){
	?>
	<div class="timeline_list">
		<div class="timeline_img">
			<a href="index.php?p=chitiettin&idTin=<?php echo $tinlienquan['idTin'] ?>">
				<img src="upload/tintuc/<?php echo $tinlienquan['urlHinh'] ?>">
		</div>
		<div class="timeline_heading">
					<?php echo $tinlienquan['TieuDe'] ?>
			</a>
		</div>
	</div>
	<?php 
		}
	?>
</div>
</div>
