<h2 style="color: #9f224e; margin-top: 10px;"><u>KẾT QUẢ TÌM KIẾM</u></h2><br>
<div class="timeline" style="border: 1px solid #ddd; padding-top: 15px">
	<?php
		$p=$_GET["p"];
		if(isset($_GET["page"])){
			$page = $_GET["page"];
			settype($page, "int");
		}else{
			$page = 1;
		}
		$from = ($page -1) * 10;
		settype($p, "int");

		$key = $_GET["key"];
		$sql = "
			SELECT * FROM tin
			WHERE TieuDe LIKE '%$key%'
			ORDER BY idTin DESC
			LIMIT $from, 10
		";
		$result = mysqli_query($con,$sql);
		
		while($tintimduoc = mysqli_fetch_array($result)){
	?>
	<div class="timeline_list">
		<div class="timeline_img">
			<a href="index.php?p=chitiettin&idTin=<?php echo $tintimduoc['idTin'] ?>">
				<img src="upload/tintuc/<?php echo $tintimduoc['urlHinh'] ?>">
			</a>
		</div>
		<div class="timeline_heading">
				<a href="index.php?p=chitiettin&idTin=<?php echo $tintimduoc['idTin'] ?>">
					<?php echo $tintimduoc['TieuDe'] ?>
				</a>
		</div>
	</div>
	<?php 
		}
	?>
	<div class="phantrang">
		<?php 
			$sql1 = "
				SELECT * FROM tin
				WHERE TieuDe LIKE '%$key%'
				ORDER BY idTin DESC
			";
		$t = mysqli_query($con,$sql1);
		$tongsotin = mysqli_num_rows($t);
		$tongsotrang = ceil($tongsotin/10);
		for($i = 1; $i<=$tongsotrang; $i++){
		?>
		<a <?php if($i==$page) echo "style='background-color:#9f224e'"; ?> href="
			index.php?key=<?php echo $key ?>&p=search&page=<?php echo $i  ?>">
			<?php echo $i ?></a>
		<?php
	 		} 	
	 	?>
	</div>
</div>