<!--tin mới nhất-->
<div class="story">
	<?php
		$sql = "
			SELECT * FROM tin
			ORDER BY idTin DESC
			LIMIT 0,1
		";
       	$result = mysqli_query($con,$sql);
        $row_tinmoinhat_mottin = mysqli_fetch_array($result);
        ?>
    <a href="index.php?p=chitiettin&idTin=<?php echo $row_tinmoinhat_mottin['idTin'] ?>">
		<img src="upload/tintuc/<?php echo $row_tinmoinhat_mottin['urlHinh'] ?>">
		<?php echo $row_tinmoinhat_mottin['TieuDe'] ?>
	</a>
</div>
<!--end tin mới nhất-->
<!--3 tin mới tiếp theo-->
<div class="rank1">
	<?php 
		$sql = "
			SELECT * FROM tin
			ORDER BY idTin DESC
			LIMIT 1,3
		";
		$result = mysqli_query($con,$sql);
		while($row_batinmoi_tieptheo = mysqli_fetch_array($result)){
	?>
	<div class="rank">
		<a href="index.php?p=chitiettin&idTin=<?php echo $row_batinmoi_tieptheo['idTin'] ?>">
			<img src="upload/tintuc/<?php echo $row_batinmoi_tieptheo['urlHinh'] ?>">
		<?php echo $row_batinmoi_tieptheo['TieuDe'] ?></a>
	</div>
	<?php
		}
	?>
</div>
<!--end 3 tin mới tiếp theo-->
<!--10 tin mới tiếp theo-->
<div class="timeline">
	<?php
		$sql = "
			SELECT * FROM tin
			ORDER BY idTin DESC
			LIMIT 4,10
		";
		$result = mysqli_query($con,$sql);
		while($row_muoitinmoi_tieptheo = mysqli_fetch_array($result)){
	?>
	<div class="timeline_list">
		<div class="timeline_img">
			<a href="index.php?p=chitiettin&idTin=<?php echo $row_muoitinmoi_tieptheo['idTin'] ?>">
				<img src="upload/tintuc/<?php echo $row_muoitinmoi_tieptheo['urlHinh'] ?>">
			</a>
		</div>
		<div class="timeline_heading">
				<a href="index.php?p=chitiettin&idTin=<?php echo $row_muoitinmoi_tieptheo['idTin'] ?>">
					<?php echo $row_muoitinmoi_tieptheo['TieuDe'] ?>
				</a>
		</div>
	</div>
	<?php 
		}
	?>
</div>
<!--end 10 tin mới tiếp theo-->
