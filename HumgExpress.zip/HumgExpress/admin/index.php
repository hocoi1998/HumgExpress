<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<tr>
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="head" colspan="11">DANH SÁCH NGƯỜI DÙNG</td>
				</tr>
				<tr class="menu2">
					<td>Id</td>
					<td>Họ Tên</td>	
					<td>Username</td>
					<td>Password</td>
					<td>Địa Chỉ</td>
					<td>Điện thoại</td>
					<td>Email</td>
					<td>Nhóm</td>
					<td>Ngày Sinh</td>
					<td>Giới Tính</td>
					
					<td ></td>
				</tr>
				<?php 
					$sql = "
						SELECT * FROM Users
						ORDER BY idUser DESC
					";
					$result = mysqli_query($con, $sql);
					while($row_user = mysqli_fetch_array($result)){
						ob_start();
				?>
				<tr>
					<td><?php echo $row_user['idUser'] ?></td>
					<td><?php echo $row_user['HoTen'] ?></td>
					<td><?php echo $row_user['Username'] ?></td>
					<td><?php echo $row_user['Password'] ?></td>
					<td><?php echo $row_user['DiaChi'] ?></td>
					<td><?php echo $row_user['Dienthoai'] ?></td>
					<td><?php echo $row_user['Email'] ?></td>
					<td>
						<?php if($row_user['idGroup']==1){echo ("Admin");
								}else{echo("Khách");}?>
					</td>
					<td><?php echo $row_user['NgaySinh'] ?></td>
					<td>
						<?php if($row_user['GioiTinh']==1	){echo ("Nam");
								}else{echo("Nữ");}?>
					</td>
				
					<td>
						<a href="suaUser.php?idUser=<?php echo $row_user['idUser'] ?>">Sửa</a> - 
						<a onclick="return confirm('Bạn có chắc muốn xoá không?')" href="xoaUser.php?idUser=<?php echo $row_user['idUser'] ?>">Xoá</a>
					</td>
				</tr>
				<?php 
					}
				?>
			</table>
		</tr>
	
	</table>
</body>
</html>
