<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<tr>
			
			<table width="1000" border="1" align="center" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan="5" class="head">DANH SÁCH TIN</td>
				</tr>
				<tr class="menu2">
					<td>id Tin</td>
					<td>Tiêu Đề - Tóm Tắt - Hình ảnh</td>
					<td>Thể Loại</td>
					<td>Số Lần Xem</td>

					<td>
						<a href="themTin.php">Thêm</a>
					</td>
				</tr>
				<?php 
				$sql = "
					SELECT tin.*, TenTL
					FROM tin, theloai
					WHERE tin.idTL = theloai.idTL
					ORDER BY idTin DESC
				
				";
				$result = mysqli_query($con, $sql);
				while($row_tin = mysqli_fetch_array($result)){
					ob_start();


			?>
				<tr>
					<td>{idTin}</td>
					<td width="500" style="text-align: left;"><a style="margin: 5px;" href="suaTin.php?idTin={idTin}">{TieuDe}</a><br>
						<img style="margin: 0px 5px; padding: 2px; float: left;" width="200" height="150" src="../upload/tintuc/{urlHinh}">
						<div style="margin: 10px">{TomTat}</div>
					</td>
					<td>{TenTL}</td>
					<td>{SoLanXem}</td>
					<td>
						<a href="suaTin.php?idTin={idTin}">Sửa</a> - 
						<a onclick="return confirm('Bạn có chắc muốn xoá không?')" href="xoaTin.php?idTin={idTin}">Xoá</a></td>
					
				</tr>
				<?php
					$s = ob_get_clean();
					$s = str_replace("{idTin}", $row_tin["idTin"], $s);
					$s = str_replace("{TieuDe}", $row_tin["TieuDe"], $s);
					$s = str_replace("{TomTat}", $row_tin["TomTat"], $s);
					$s = str_replace("{TenTL}", $row_tin["TenTL"], $s);
					$s = str_replace("{SoLanXem}", $row_tin["SoLanXem"], $s);
					$s = str_replace("{urlHinh}", $row_tin["urlHinh"], $s);
					echo $s; 
					}
				?>
			</table>
		</tr>
	
	</table>
</body>
</html>
