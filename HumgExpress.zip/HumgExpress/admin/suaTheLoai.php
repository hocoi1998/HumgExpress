<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idTL = $_GET["idTL"];
		settype($idTL, "int");
	$sql = "
		SELECT * FROM theloai
		WHERE idTL = '$idTL'
		";
		$result = mysqli_query($con,$sql);
		$row_theloai = mysqli_fetch_array($result);
?>
<?php 
	if(isset($_POST["fix"])){
		$TenTL = $_POST["TenTL"];
		$sql = "
			UPDATE theloai SET
			TenTL ='$TenTL'
			WHERE idTL ='$idTL'
		";
		mysqli_query($con, $sql);
		header("location:listTheLoai.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="list" colspan="2">Sửa thể loại</td>
				</tr>
				<tr>
					<td class="haicot">Tên Thể Loại</td>
					<td class="haicot">
						<input value="<?php echo $row_theloai["TenTL"] ?>" type="text" name="TenTL" size="67">
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="fix" value=" Sửa ">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
