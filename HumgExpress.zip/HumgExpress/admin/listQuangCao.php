<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 }
 require "../lib/config.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?>
				<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<tr>
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="head" colspan="6">DANH SÁCH QUẢNG CÁO</td>
				</tr>
				<tr class="menu2">
					<td width="50">id</td>
					<td width="50">Vị trí</td>
					<td width="130">Mô tả</td>
					<td>Link</td>	
					<td width="200">Hình ảnh</td>
					<td><a href="themQuangCao.php">Thêm</a></td>
				</tr>
				<?php 
					$sql = "
						SELECT * FROM quangcao
						ORDER BY idQC DESC
					";
					$result = mysqli_query($con, $sql);
					while($row_quangcao = mysqli_fetch_array($result)){
				?>
				<tr>
					<td><?php echo $row_quangcao["idQC"] ?></td>
					<td>
							<?php 
								if($row_quangcao['vitri']==1){
									echo ("Trên");
								}else{
									echo("Phải");
								}
							?>
			
						</td>
					<td><?php echo $row_quangcao["MoTa"] ?></td>
					<td style="text-align: left;max-width: 450px;word-wrap: break-word;">
						<a target="_blank" href="<?php echo $row_quangcao["Url"] ?>" ><?php echo $row_quangcao["Url"] ?></a>
					</td>

					<td><?php echo $row_quangcao["urlHinh"] ?></td>
					<td>
						<a href="suaQuangCao.php?idQC=<?php echo $row_quangcao["idQC"] ?>">Sửa</a> - 
						<a onclick="return confirm('Bạn có chắc muốn xoá không?')" href="xoaQuangCao.php?idQC=<?php echo $row_quangcao["idQC"] ?>">Xoá</a>
					</td>
				</tr>
				<?php 
					}
				?>
			</table>
		</tr>
	</table>
</body>
</html>
