<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idQC = $_GET["idQC"];
		settype($idQC, "int");
	$sql ="
		DELETE FROM quangcao
		WHERE idQC = '$idQC'
	";
	mysqli_query($con,$sql);
	header("location:listQuangCao.php");

?>