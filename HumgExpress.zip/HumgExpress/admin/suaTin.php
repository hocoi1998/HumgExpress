<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idTin = $_GET["idTin"];
		settype($idTin, "int");
	$sql = "
		SELECT * FROM tin
		WHERE idTin = '$idTin'
		";
		$result = mysqli_query($con,$sql);
		$row_tin = mysqli_fetch_array($result);

?>
<?php 
	if(isset($_POST["fix"])){
		$TieuDe = $_POST["TieuDe"];
		$fixTieuDe = str_replace("'","\'" , $TieuDe);
		
		$TomTat = $_POST["TomTat"];
		$fixTomTat = str_replace("'","\'" ,$TomTat);
		$urlHinh = $_POST["urlHinh"];
		$Content = $_POST['Content'];
		$fixContent = str_replace("'","\'" ,$Content);
		$idTL = $_POST["idTL"];
		$sql = "
		
			UPDATE tin SET
			TieuDe ='$fixTieuDe',
			TomTat ='$fixTomTat',
			urlHinh = '$urlHinh',
			Content = '$fixContent',
			idTL = '$idTL'
			WHERE idTin ='$idTin'
		";
		mysqli_query($con, $sql);
		header("location:listTin.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="plugin/tinymce/js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript" src="plugin/tinymce/js/tinymce/init-tinymce.js"></script>
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="list" colspan="2">Sửa tin</td>
				</tr>
				<tr>
					<td width="150">Tiêu Đề</td>
					<td>
						<input value="<?php echo $row_tin["TieuDe"] ?>" type="text" name="TieuDe" size="116">
					</td>
				</tr>
				<tr>
					<td>Tóm tắt</td>
					<td>
						<textarea cols="118" rows="4" name="TomTat" value="">
							<?php echo $row_tin["TomTat"] ?>
						</textarea>
					</td>
				</tr>
				<tr>
					<td>Hình ảnh</td>
					<td>
						<input value="<?php echo $row_tin["urlHinh"] ?>" type="text" name="urlHinh" size="78">
						<input type="file" name="urlHinh">
					</td>
				</tr>
				<tr>
					<td>Nội dung</td>
					<td>
						<textarea class="tinymce" cols="116" rows="20" name="Content" id="Content" value="">
							<?php echo $row_tin['Content'] ?>
						</textarea>
						
					</td>
				</tr>
				<tr>
					<td>Thể loại</td>
					<td>
						<Select name="idTL" >
							<?php 
								$sql = "
									SELECT * FROM theloai
									ORDER BY idTL DESC
									";
								$result = mysqli_query($con, $sql);
								while($row_theloai = mysqli_fetch_array($result)){
									
							?>
								<option  value="<?php echo $row_theloai["idTL"] ?>"><?php echo $row_theloai["TenTL"] ?>
									
								</option>
							<?php 
								 }
							?>
							
						</Select>
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="fix" value=" Sửa ">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
