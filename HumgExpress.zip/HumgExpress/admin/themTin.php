<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	if(isset($_POST["add"])){
		$TieuDe = $_POST["TieuDe"];
		$fixTieuDe = str_replace("'","\'" , $TieuDe);

		$TomTat = $_POST["TomTat"];
		$fixTomTat = str_replace("'","\'" , $TomTat);
		$urlHinh = $_POST["urlHinh"];
			
		$Content = $_POST["Content"];
		$fixContent = str_replace("'","\'" , $Content);
		$idTL = $_POST["idTL"];
		
		
	 $sql1 = "
		INSERT INTO tin 
		VALUES(null,'$fixTieuDe','$fixTomTat','$urlHinh','','$fixContent','$idTL','')
		";
	mysqli_query($con,$sql1);
	header("location:listTin.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="plugin/tinymce/js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript" src="plugin/tinymce/js/tinymce/init-tinymce.js"></script>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<tr>
			<form action="" method="POST">
			<table width="1000" border="1" align="center" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan="2">THÊM TIN</td>
			
				</tr>
				<tr>
					<td width="200">Tiêu đề</td>
					<td >
						<input size="109" type="text" name="TieuDe">
					</td>
				</tr>
				
				<tr>
					<td>Tóm tắt</td>
					<td>
						<textarea cols="110" rows="5" name="TomTat"></textarea>
					</td>
				</tr>
				<tr>
					<td>Hình ảnh</td>
					<td>
				
						<input type="file" name="urlHinh" value="Browers">
					</td>
				</tr>
				<tr>
					<td>Nội dung</td>
					<td>
						<textarea class="tinymce" cols="110" rows="20"  name="Content"></textarea>
						
					</td>
				</tr>
				<tr>
					<td>ID Thể Loại</td>
					<td>
						<Select name="idTL" >
							<?php 
								$sql = "
									SELECT * FROM theloai
									ORDER BY idTL DESC
									";
								$result = mysqli_query($con, $sql);
								while($row_theloai = mysqli_fetch_array($result)){
									
							?>
								<option  value="<?php echo $row_theloai["idTL"] ?>"><?php echo $row_theloai["TenTL"] ?>
									
								</option>
							<?php 
								 }
							?>
							
						</Select>
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="add" value=" Thêm ">
					</td>
				</tr>
			</table>
		</form>
		</tr>
	
	</table>
</body>
</html>
