<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idUser = $_GET["idUser"];
		settype($idUser, "int");
	$sql = "
		SELECT * FROM users
		WHERE idUser = '$idUser'
		";
		$result = mysqli_query($con,$sql);
		$row_user = mysqli_fetch_array($result);
?>
<?php 
	if(isset($_POST["fix"])){
		$HoTen = $_POST["HoTen"];
		$Username = $_POST["Username"];
		$Password = $_POST['Password'];
		$DiaChi = $_POST['DiaChi'];
		$Dienthoai = $_POST['Dienthoai'];
		$Email = $_POST['Email'];
		$idGroup = $_POST['idGroup'];
		$NgaySinh = $_POST['NgaySinh'];
		$GioiTinh =$_POST['GioiTinh'];
		$sql = "
			UPDATE users SET
			HoTen ='$HoTen',
			Username = '$Username',
			Password = '$Password',
			DiaChi = '$DiaChi',
			Dienthoai = '$Dienthoai',
			Email = '$Email',
			idGroup = '$idGroup',
			NgaySinh = '$NgaySinh',
			GioiTinh = '$GioiTinh'
			WHERE idUser ='$idUser'
		";
		mysqli_query($con, $sql);
		header("location:index.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="list" colspan="2">Sửa thông tin khách hàng</td>
				</tr>
				<tr>
					<td class="haicot">Họ Tên</td>
					<td class="haicot">
						<input value="<?php echo $row_user["HoTen"] ?>" type="text" name="HoTen" size="67">
					</td>
				</tr>
				<tr>
					<td>Username</td>
					<td>
						<input type="text" name="Username" value="<?php echo $row_user["Username"] ?>"size="67">
					</td>
				</tr>
				<tr>
					<td>Password</td>
					<td>
						<input type="Password" name="Password" value="<?php echo $row_user["Password"] ?>"size="67">
					</td>
				</tr>
				<tr>
					<td>Địa chỉ</td>
					<td>
						<input type="text" name="DiaChi" value="<?php echo $row_user["DiaChi"] ?>"size="67">
					</td>
				</tr>
				<tr>
					<td>Điện thoại</td>
					<td>
						<input style="float: left;" type="number" name="Dienthoai" value="<?php echo $row_user["Dienthoai"] ?>">
					</td>
				</tr>
				<tr>
					<td>Email</td>
					<td>
						<input type="text" name="Email" value="<?php echo $row_user["Email"] ?>"size="67">
					</td>
				</tr>
				<tr>
					<td>Nhóm</td>
					<td>
						<div style="float: left;margin-left: 20px">
							<input style="float: left;" <?php if($row_user['idGroup']==1) echo "checked = 'checked'"; ?> type="radio" name="idGroup" value="1" >
							<div style="float: left;margin-top: 10px">Admin</div><br>
						</div>
						<div style="float: left; clear: both; margin-left: 20px">
							<input style="float: left;" <?php if($row_user['idGroup']==0) echo "checked = 'checked'"; ?>  type="radio" name="idGroup" value ="0" >
							<div style="float: left;margin-top: 10px">Khách</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>Ngày Sinh</td>
					<td>
						<input style="float: left;" type="date" name="NgaySinh" value="<?php echo $row_user["NgaySinh"] ?>">
					</td>
				</tr>
				<tr>
					<td>Giới tính</td>
					<td>
						<div style="float: left;margin-left: 20px">
							<input style="float: left;" <?php if($row_user['GioiTinh']==1) echo "checked = 'checked'"; ?> type="radio" name="GioiTinh" value="1" >
							<div style="float: left;margin-top: 10px">Nam</div><br>
						</div>
						<div style="float: left; clear: both; margin-left: 20px">
							<input style="float: left;" <?php if($row_user['GioiTinh']==0) echo "checked = 'checked'"; ?>  type="radio" name="GioiTinh" value ="0" >
							<div style="float: left;margin-top: 10px">Nữ</div>
						</div>
					</td>
				</tr>
				<tr></tr>
				<tr>
					<td></td>
					<td>
						<input style="float: left;" type="submit" name="fix" value="&#09; Sửa &#09;">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
