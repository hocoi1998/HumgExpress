<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idTin = $_GET["idTin"];
		settype($idTL, "int");
	$sql ="
		DELETE FROM tin
		WHERE idTin = '$idTin'
	";
	mysqli_query($con,$sql);
	header("location:listTin.php");

?>