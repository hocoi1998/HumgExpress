<a href="./">Quản lý người dùng</a>
<a href="ListTheLoai.php">Quản lý thể loại</a>
<a href="ListTin.php">Quản lý tin tức</a>
<a href="ListQuangCao.php">Quản lý quảng cáo</a>