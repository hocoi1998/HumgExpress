<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idUser = $_GET["idUser"];
		settype($idUser, "int");
	$sql ="
		DELETE FROM users
		WHERE idUser = '$idUser'
	";
	mysqli_query($con,$sql);
	header("location:index.php");

?>