<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idTL = $_GET["idTL"];
		settype($idTL, "int");
	$sql ="
		DELETE FROM theloai
		WHERE idTL = '$idTL'
	";
	mysqli_query($con,$sql);
	header("location:listTheLoai.php");

?>