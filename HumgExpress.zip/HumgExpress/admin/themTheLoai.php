<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	if(isset($_POST["add"])){
		$TenTL = $_POST["TenTL"];
		$sql = "
		INSERT INTO theloai
		VALUE(null,'$TenTL')
		";
		mysqli_query($con,$sql);
		header("location:listTheLoai.php");
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="list" colspan="2">Thêm thể loại</td>
				</tr>
				<tr>
					<td class="haicot">TenTL</td>
					<td class="haicot">
						<input type="text" name="TenTL" size="67">
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="add" value=" Thêm ">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
