<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	$idQC = $_GET["idQC"];
		settype($idQC, "int");
	$sql = "
		SELECT * FROM quangcao
		WHERE idQC = '$idQC'
		";
		$result = mysqli_query($con,$sql);
		$row_quangcao = mysqli_fetch_array($result);

?>
<?php 
	if(isset($_POST["fix"])){
		$MoTa = $_POST["MoTa"];
		$vitri = $_POST["vitri"];
			settype($vitri, "int");
		$Url = $_POST['Url'];
		$urlHinh = $_POST['urlHinh'];
		$sql = "
			UPDATE quangcao SET
			vitri ='$vitri',
			MoTa ='$MoTa',
			Url = '$Url',
			urlHinh = '$urlHinh'
			WHERE idQC ='$idQC'
		";
		mysqli_query($con, $sql);
		header("location:listQuangCao.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="list" colspan="2">SỬA QUẢNG CÁO</td>
				</tr>
				<tr>
					<td>Vị trí</td>
					<td>
						<div style="float: left;margin-left: 20px">
							<input style="float: left;" <?php if($row_quangcao['vitri']==1) echo "checked = 'checked'"; ?> type="radio" name="vitri" value="1" >
							<div style="float: left;margin-top: 10px">Trên</div><br>
						</div>
						<div style="float: left; clear: both; margin-left: 20px">
							<input style="float: left;" <?php if($row_quangcao['vitri']==2) echo "checked = 'checked'"; ?>  type="radio" name="vitri" value ="2" >
							<div style="float: left;margin-top: 10px">Phải</div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="haicot">Mô tả</td>
					<td class="haicot">
						<input value="<?php echo $row_quangcao["MoTa"] ?>" type="text" name="MoTa" size="67">
					</td>
				</tr>
				<tr>
					<td>Link</td>
					<td>
						<textarea cols="90" rows="5" type="text" name="Url"  >
							<?php echo $row_quangcao["Url"] ?>
						</textarea>
						
					</td>
				</tr>
				<tr>
					<td>Hình ảnh</td>
					<td>
						<input type="file" name="urlHinh">
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="fix" value=" Sửa ">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
