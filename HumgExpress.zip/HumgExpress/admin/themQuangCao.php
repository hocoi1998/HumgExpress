<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 		}
 require "../lib/config.php";

?>
<?php 
	if(isset($_POST["add"])){
		$vitri = $_POST["vitri"];
		$MoTa = $_POST["MoTa"];
		$Url = $_POST["Url"];
		$urlHinh = $_POST["urlHinh"];
		$sql = "
		INSERT INTO quangcao
		VALUE(null,'$vitri','$MoTa','$Url','$urlHinh')
		";
		mysqli_query($con,$sql);
		header("location:listQuangCao.php");
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?><br>
			<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<form action="" method="POST">
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="list" colspan="2">Thêm quảng cáo</td>
				</tr>
				<tr>
					<td class="haicot">Vị Trí</td>
					<td class="haicot">
						<div style="float: left;margin-left: 20px">
							<input style="float: left;" type="radio" name="vitri" value="1">
							<div style="float: left; margin-top: 10px">Trên</div><br>
						</div>
						<div style="float: left; clear: both; margin-left: 20px">
							<input style="float: left;" type="radio" name="vitri" value="2">
							<div style="float: left;margin-top: 10px;">Phải</div>
						</div>

				</tr>
				<tr>
					<td>Mô Tả</td>
					<td>
						<input size="70" type="text" name="MoTa" >
					</td>
				</tr>
				<tr>
					<td>Link</td>
					<td>
						<textarea rows="10" cols="72" name="Url"></textarea>
					</td>
				</tr>
				<tr>
					<td>Hình ảnh</td>
					<td>
						<input type="file" name="urlHinh">
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<input type="submit" name="add" value=" Thêm ">
					</td>
				</tr>
			</table>
		</form>
	</table>
</body>
</html>
