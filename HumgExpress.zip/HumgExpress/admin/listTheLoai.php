<?php 
	ob_start();
	session_start();
		if(!isset($_SESSION["idUser"]) || $_SESSION["idGroup"]==0 ){
	  	header("location:../index.php"); 
 }
 require "../lib/config.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title>HumgExpress | Trang quản trị</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td class="tit">TRANG QUẢN TRỊ
			<div class="hello">Chào <?php echo $_SESSION["HoTen"] ?>
				<div class="homepage">
				<a href="../index.php">
					Đi tới trang người dùng
				</a>
			</div>
			</div>
			</td>
			
		</tr>
		<tr>
			<td class="menu"><?php require "menu.php"; ?></td>
		</tr>
		<tr>
			<table width="1000" align="center" cellspacing="0" border="1">
				<tr>
					<td class="head" colspan="3">DANH SÁCH THỂ LOẠI</td>
				</tr>
				<tr class="menu2">
					<td class="theloai">Id</td>
					<td class="theloai">Thể Loại</td>	
					<td class="theloai"><a href="themtheloai.php">Thêm</a></td>
				</tr>
				<?php 
					$sql = "
						SELECT * FROM theloai
						ORDER BY idTL DESC
					";
					$result = mysqli_query($con, $sql);
					while($row_theloai = mysqli_fetch_array($result)){
						ob_start();
				?>
				<tr>
					<td class="theloai">{idTL}</td>
					<td class="theloai">{TenTL}</td>
					<td class="theloai">
						<a href="suaTheLoai.php?idTL={idTL}">Sửa</a> - 
						<a onclick="return confirm('Bạn có chắc muốn xoá không?')" href="xoaTheLoai.php?idTL={idTL}">Xoá</a>
					</td>
				</tr>
				<?php 
					$s = ob_get_clean();
					$s = str_replace("{idTL}", $row_theloai["idTL"], $s);
					$s = str_replace("{TenTL}", $row_theloai["TenTL"], $s);
					echo $s;
					}
				?>
			</table>
		</tr>
	</table>
</body>
</html>
